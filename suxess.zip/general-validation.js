// const form = document.getElementById("general-form");
// const name = document.getElementById("general-name");
// const startupName = document.getElementById("general-startupname");
// const contact = document.getElementById("general-contact");
// const mail = document.getElementById("general-mail");
// const designation = document.getElementById("general-designation");

// function checkLength(input, min, max){
//   if()
// }